/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysqlConec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class MySQLConnec {
//1)-Atributos

    private String JDBC;
    private String Pass;
    private String Root;

    //2)-Costructor vacio
    public MySQLConnec() {

    }

    //Constructor Argumrntos
    public MySQLConnec(String JDBC, String Pass, String Root) {
        this.JDBC = JDBC;
        this.Pass = Pass;
        this.Root = Root;
    }

    public String coneccion(String JDBC, String Root, String Pass) {
        Connection con;

        /*
        String user = "root";
        String pass = "";
        String url = "jdbc:mysql://localhost:3306/damit";
         */
        con = null;
        try {

            con = (Connection) DriverManager.getConnection(JDBC, Root, Pass);

            if (con != null) {
                return "Conectado";
            }
            return "Conectado";
        } catch (SQLException ex) {
            System.out.println("Fallo..." + ex.getMessage());
        }
        return "Fallo...";

    }

}
